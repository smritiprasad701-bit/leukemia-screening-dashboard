"""
PHASE 7 - Grad-CAM explainability.

Produces: original image, predicted class + probability, raw heatmap, and heatmap
overlay. This shows WHICH REGIONS of the image most influenced the model's decision
-- it does NOT prove the model's reasoning is medically correct. A model can produce a
plausible-looking heatmap while still relying on spurious correlations (e.g., staining
artifacts); Grad-CAM is a debugging/interpretability aid, not a validation of clinical
correctness. Always interpret it alongside quantitative evaluation, not instead of it.

Run:
    python src/gradcam.py --config configs/config.yaml --checkpoint models/baseline_best.pt --image path/to/img.bmp
"""
import argparse
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from PIL import Image
import matplotlib.pyplot as plt
from pytorch_grad_cam import GradCAM
from pytorch_grad_cam.utils.image import show_cam_on_image

from utils import load_config, get_device, ensure_dirs
from preprocessing import get_eval_transforms, IMAGENET_MEAN, IMAGENET_STD
from models import build_model


def get_target_layer(model, model_type: str, cfg: dict):
    arch = cfg["model"]["baseline_arch"] if model_type == "baseline" else cfg["model"]["advanced_arch"]
    layer_name = cfg["gradcam"]["target_layer"].get(arch)
    if layer_name is None:
        raise ValueError(f"No Grad-CAM target layer configured for architecture '{arch}'. "
                          f"Add it to configs/config.yaml under gradcam.target_layer.")
    module = dict(model.named_modules()).get(layer_name)
    if module is None:
        raise ValueError(f"Layer '{layer_name}' not found in model. Inspect model.named_modules() "
                          f"and update the config.")
    return module


def run_gradcam(cfg_path: str, checkpoint_path: str, image_path: str, out_dir: str = "outputs/gradcam"):
    cfg = load_config(cfg_path)
    device = get_device()

    ckpt = torch.load(checkpoint_path, map_location=device)
    run_name = Path(checkpoint_path).stem.replace("_best", "")
    model_type = "baseline" if "baseline" in run_name else "advanced"
    model = build_model(model_type, cfg).to(device)
    model.load_state_dict(ckpt["model_state_dict"])
    model.eval()

    target_layer = get_target_layer(model, model_type, cfg)

    image_size = cfg["data"]["image_size"]
    transforms = get_eval_transforms(image_size)

    pil_img = Image.open(image_path).convert("RGB")
    rgb_img = np.array(pil_img.resize((image_size, image_size))).astype(np.float32) / 255.0

    tensor_img = transforms(image=np.array(pil_img))["image"].unsqueeze(0).to(device)

    with torch.no_grad():
        logits = model(tensor_img)
        probs = F.softmax(logits, dim=1)[0]
        pred_class = int(probs.argmax())
        pred_prob = float(probs[pred_class])

    cam = GradCAM(model=model, target_layers=[target_layer])
    grayscale_cam = cam(input_tensor=tensor_img)[0]  # HxW, 0-1
    overlay = show_cam_on_image(rgb_img, grayscale_cam, use_rgb=True)

    ensure_dirs(out_dir)
    class_name = cfg["data"]["class_names"][pred_class]

    fig, axes = plt.subplots(1, 3, figsize=(12, 4))
    axes[0].imshow(rgb_img); axes[0].set_title("Original"); axes[0].axis("off")
    axes[1].imshow(grayscale_cam, cmap="jet"); axes[1].set_title("Grad-CAM heatmap"); axes[1].axis("off")
    axes[2].imshow(overlay); axes[2].set_title(f"Overlay\nPred: {class_name} ({pred_prob:.2%})"); axes[2].axis("off")
    plt.tight_layout()

    out_path = Path(out_dir) / f"{Path(image_path).stem}_gradcam.png"
    plt.savefig(out_path, dpi=150)
    plt.close()
    print(f"Grad-CAM saved to {out_path}")
    print(f"Predicted class: {class_name}, probability: {pred_prob:.4f}")
    return out_path, class_name, pred_prob


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="configs/config.yaml")
    parser.add_argument("--checkpoint", required=True)
    parser.add_argument("--image", required=True)
    args = parser.parse_args()
    run_gradcam(args.config, args.checkpoint, args.image)


if __name__ == "__main__":
    main()
