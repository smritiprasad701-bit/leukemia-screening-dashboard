"""
PHASE 4 - Baseline model training: ResNet50 with ImageNet transfer learning.

Why ResNet50: strong, well-understood, widely-benchmarked backbone; good balance
of accuracy and training cost for a single-GPU/Colab student project; extensive
prior work on this exact dataset uses it as a standard baseline, enabling fair
comparison in your report's literature-comparison table.

Strategy: freeze the backbone for `freeze_backbone_epochs`, train only the new
classification head, then unfreeze everything and fine-tune end-to-end at a lower
implicit learning rate (the scheduler continues decaying).

Run:
    python src/train_baseline.py --config configs/config.yaml
"""
import argparse

import torch

from utils import load_config, set_seed, get_device
from dataset import build_dataloaders
from models import build_model, freeze_backbone, unfreeze_all
from engine import train_model


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="configs/config.yaml")
    args = parser.parse_args()

    cfg = load_config(args.config)
    set_seed(cfg["seed"])
    device = get_device()
    print(f"Using device: {device}")

    train_loader, val_loader, _ = build_dataloaders(cfg)

    model = build_model("baseline", cfg).to(device)

    freeze_epochs = cfg["training"]["freeze_backbone_epochs"]
    if freeze_epochs > 0:
        print(f"Freezing backbone for first {freeze_epochs} epochs (head-only warm-up)...")
        freeze_backbone(model, cfg["model"]["baseline_arch"])
        warmup_cfg = dict(cfg)
        warmup_cfg["training"] = dict(cfg["training"])
        warmup_cfg["training"]["epochs"] = freeze_epochs
        warmup_cfg["training"]["early_stopping_patience"] = freeze_epochs + 1  # don't stop during warmup
        train_model(model, train_loader, val_loader, warmup_cfg, device, run_name="baseline_warmup")

    print("Unfreezing full model for end-to-end fine-tuning...")
    unfreeze_all(model)
    history, best_path = train_model(model, train_loader, val_loader, cfg, device, run_name="baseline")

    print(f"Training complete. Best checkpoint: {best_path}")


if __name__ == "__main__":
    main()
