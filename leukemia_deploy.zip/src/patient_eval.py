"""
PHASE 8 - Patient/sample-level evaluation.

An image-level (per-cell) prediction is NOT the same as a patient-level diagnosis.
A single blood sample yields many cell images; a clinically meaningful evaluation
must aggregate cell-level predictions into ONE prediction per patient/subject, using
only images from that patient's TEST split (never mixed with train/val subjects --
this reuses the same manifest produced by split_patient_level.py, so it's leakage-safe
by construction).

Aggregation rule implemented: a patient/sample is flagged "suspicious for ALL" if the
proportion of cells predicted "all" exceeds a threshold (default 0.5, i.e. majority
vote at the cell level -- also reports mean-probability aggregation as an alternative).

This script ALSO implements confidence-based flagging: any individual image whose
maximum softmax probability is below `evaluation.low_confidence_threshold` is flagged
"low confidence - recommend human review" rather than being silently trusted.

IMPORTANT: softmax probability is a measure of the model's own confidence given its
training distribution -- it is NOT the same as true clinical certainty. A model can be
confidently wrong, especially on inputs that differ from its training data (domain
shift). Confidence should be used to triage cases for human review, never as a
stand-alone diagnostic guarantee.

Run:
    python src/patient_eval.py --config configs/config.yaml --checkpoint models/baseline_best.pt
"""
import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
import torch
from sklearn.metrics import confusion_matrix, roc_auc_score

from utils import load_config, set_seed, get_device, ensure_dirs
from dataset import build_dataloaders
from models import build_model
from evaluate import get_predictions, compute_metrics


def aggregate_to_patient_level(y_true, y_pred, y_prob, subjects, vote_threshold: float = 0.5) -> pd.DataFrame:
    df = pd.DataFrame({"subject_id": subjects, "y_true": y_true, "y_pred": y_pred, "y_prob": y_prob})
    agg = df.groupby("subject_id").agg(
        n_cells=("y_true", "count"),
        true_label=("y_true", lambda s: s.mode().iloc[0]),   # ground-truth subject label
        frac_predicted_all=("y_pred", "mean"),                 # fraction of cells predicted class 1
        mean_prob_all=("y_prob", "mean"),
    ).reset_index()
    agg["patient_pred_majority"] = (agg["frac_predicted_all"] >= vote_threshold).astype(int)
    agg["patient_pred_meanprob"] = (agg["mean_prob_all"] >= 0.5).astype(int)
    return agg


def flag_low_confidence(y_prob, threshold: float) -> np.ndarray:
    """An image is 'low confidence' if max(p_class0, p_class1) is below threshold."""
    max_prob = np.maximum(y_prob, 1 - y_prob)
    return max_prob < threshold


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="configs/config.yaml")
    parser.add_argument("--checkpoint", required=True)
    args = parser.parse_args()

    cfg = load_config(args.config)
    set_seed(cfg["seed"])
    device = get_device()

    ckpt = torch.load(args.checkpoint, map_location=device)
    run_name = Path(args.checkpoint).stem.replace("_best", "")
    model_type = "baseline" if "baseline" in run_name else "advanced"
    model = build_model(model_type, cfg).to(device)
    model.load_state_dict(ckpt["model_state_dict"])

    _, _, test_loader = build_dataloaders(cfg)
    y_true, y_pred, y_prob, subjects = get_predictions(model, test_loader, device)

    # image-level low-confidence flagging
    low_conf_mask = flag_low_confidence(y_prob, cfg["evaluation"]["low_confidence_threshold"])
    print(f"Low-confidence images flagged for human review: {low_conf_mask.sum()} / {len(y_prob)} "
          f"({100*low_conf_mask.mean():.1f}%)")

    # patient-level aggregation
    patient_df = aggregate_to_patient_level(y_true, y_pred, y_prob, subjects)
    patient_metrics_majority = compute_metrics(
        patient_df["true_label"].values, patient_df["patient_pred_majority"].values, patient_df["mean_prob_all"].values
    )
    patient_metrics_meanprob = compute_metrics(
        patient_df["true_label"].values, patient_df["patient_pred_meanprob"].values, patient_df["mean_prob_all"].values
    )

    print("\n=== Patient-level metrics (majority-vote aggregation) ===")
    print(json.dumps(patient_metrics_majority, indent=2))
    print("\n=== Patient-level metrics (mean-probability aggregation) ===")
    print(json.dumps(patient_metrics_meanprob, indent=2))

    out_dir = Path(cfg["evaluation"]["outputs_dir"])
    ensure_dirs(out_dir)
    patient_df.to_csv(out_dir / f"{run_name}_patient_level_predictions.csv", index=False)
    with open(out_dir / f"{run_name}_patient_level_metrics.json", "w") as f:
        json.dump({"majority_vote": patient_metrics_majority, "mean_probability": patient_metrics_meanprob}, f, indent=2)

    print(f"\nSaved patient-level predictions and metrics under {out_dir}")


if __name__ == "__main__":
    main()
