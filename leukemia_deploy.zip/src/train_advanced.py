"""
PHASE 5 - Advanced model training: EfficientNet-B0 (default) or Vision Transformer
(set model.advanced_arch: "vit_small_patch16_224" in config.yaml).

Why this might beat ResNet50 on blood-smear images:
  - EfficientNet's compound scaling gives a better accuracy/parameter trade-off,
    useful when the dataset (thousands, not millions, of images) can't fully exploit
    a very large backbone.
  - ViT-style attention can, in principle, capture long-range spatial relationships
    (e.g., nucleus-to-cytoplasm ratio across the whole cell) but ViTs are typically
    more data-hungry and may UNDERPERFORM a CNN on a dataset this size unless
    initialized from strong pretraining and fine-tuned carefully -- report this
    trade-off honestly rather than assuming the "newer" model automatically wins.

Run:
    python src/train_advanced.py --config configs/config.yaml
"""
import argparse

from utils import load_config, set_seed, get_device
from dataset import build_dataloaders
from models import build_model, freeze_backbone, unfreeze_all
from engine import train_model


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="configs/config.yaml")
    args = parser.parse_args()

    cfg = load_config(args.config)
    set_seed(cfg["seed"])
    device = get_device()
    print(f"Using device: {device}")
    print(f"Advanced architecture: {cfg['model']['advanced_arch']}")

    train_loader, val_loader, _ = build_dataloaders(cfg)

    model = build_model("advanced", cfg).to(device)

    freeze_epochs = cfg["training"]["freeze_backbone_epochs"]
    if freeze_epochs > 0:
        print(f"Freezing backbone for first {freeze_epochs} epochs...")
        freeze_backbone(model, cfg["model"]["advanced_arch"])
        warmup_cfg = dict(cfg)
        warmup_cfg["training"] = dict(cfg["training"])
        warmup_cfg["training"]["epochs"] = freeze_epochs
        warmup_cfg["training"]["early_stopping_patience"] = freeze_epochs + 1
        train_model(model, train_loader, val_loader, warmup_cfg, device, run_name="advanced_warmup")

    print("Unfreezing full model for end-to-end fine-tuning...")
    unfreeze_all(model)
    history, best_path = train_model(model, train_loader, val_loader, cfg, device, run_name="advanced")

    print(f"Training complete. Best checkpoint: {best_path}")


if __name__ == "__main__":
    main()
