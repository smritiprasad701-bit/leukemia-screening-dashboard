"""
Patient/subject-level train/val/test split for C-NMC 2019.

WHY THIS FILE EXISTS (read this before touching it):
C-NMC 2019 provides MANY single-cell crops per patient/subject. If you split at the
IMAGE level (random shuffle of all images), cells from the SAME patient end up in both
train and test. The model can then partly "memorize" that patient's staining/illumination
signature rather than learning general leukemia morphology -> inflated, misleading test
accuracy. This is DATA LEAKAGE and is one of the most common mistakes in this literature.

This script instead:
  1. Parses the subject/UID token out of each filename.
  2. Splits UNIQUE SUBJECTS (not images) into train / val / test.
  3. Assigns every image belonging to a subject to that subject's split.

Run:
    python src/split_patient_level.py --config configs/config.yaml
Output:
    data/processed/split_manifest.csv  with columns: filepath,label,subject_id,split
"""
import argparse
import re
from pathlib import Path

import pandas as pd
from sklearn.model_selection import train_test_split

from utils import load_config, set_seed, ensure_dirs, get_logger

logger = get_logger("split_patient_level")

# C-NMC filenames look like: UID_H21_1_1_hem.bmp  or  UID_23_5_2_all.bmp
# The token right after "UID_" (up to the next underscore run that starts the numeric
# image-index part) identifies the subject. We use a permissive regex and fall back to
# "parent folder name" if the filename doesn't match, since raw TCIA exports sometimes
# nest folders per subject as well.
UID_PATTERN = re.compile(r"UID_([A-Za-z0-9]+)_")


def extract_subject_id(filepath: Path) -> str:
    m = UID_PATTERN.search(filepath.name)
    if m:
        return m.group(1)
    # fallback: use the immediate parent-of-parent folder (per-subject folder in some exports)
    return filepath.parent.parent.name


def scan_raw_dir(raw_dir: Path) -> pd.DataFrame:
    rows = []
    for label_name, label_id in [("hem", 0), ("all", 1)]:
        for img_path in raw_dir.rglob(f"*/{label_name}/*"):
            if img_path.suffix.lower() not in {".bmp", ".png", ".jpg", ".jpeg", ".tif", ".tiff"}:
                continue
            subject_id = extract_subject_id(img_path)
            rows.append({
                "filepath": str(img_path),
                "label": label_id,
                "label_name": label_name,
                "subject_id": subject_id,
            })
    df = pd.DataFrame(rows)
    if df.empty:
        raise RuntimeError(
            f"No images found under {raw_dir}. Check data/README.md for expected layout."
        )
    return df


def subject_level_split(df: pd.DataFrame, val_frac: float, test_frac: float, seed: int) -> pd.DataFrame:
    # One row per subject, with the subject's MAJORITY label (a subject is normally
    # entirely 'all' or entirely 'hem' in C-NMC, so this is just a safety net).
    subj_labels = df.groupby("subject_id")["label"].agg(lambda s: s.mode().iloc[0]).reset_index()

    train_subj, test_subj = train_test_split(
        subj_labels, test_size=test_frac, stratify=subj_labels["label"], random_state=seed
    )
    # val_frac is expressed as a fraction of the ORIGINAL whole; convert to fraction of train_subj
    relative_val_frac = val_frac / (1 - test_frac)
    train_subj, val_subj = train_test_split(
        train_subj, test_size=relative_val_frac, stratify=train_subj["label"], random_state=seed
    )

    split_map = {}
    for s in train_subj["subject_id"]:
        split_map[s] = "train"
    for s in val_subj["subject_id"]:
        split_map[s] = "val"
    for s in test_subj["subject_id"]:
        split_map[s] = "test"

    df = df.copy()
    df["split"] = df["subject_id"].map(split_map)
    return df


def assert_no_leakage(df: pd.DataFrame):
    """Hard check: no subject appears in more than one split."""
    pivot = df.groupby("subject_id")["split"].nunique()
    leaking = pivot[pivot > 1]
    if len(leaking) > 0:
        raise AssertionError(f"Data leakage detected! Subjects in multiple splits: {list(leaking.index)}")
    logger.info("Leakage check passed: every subject is confined to exactly one split.")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="configs/config.yaml")
    args = parser.parse_args()

    cfg = load_config(args.config)
    set_seed(cfg["seed"])
    ensure_dirs(cfg["data"]["processed_dir"])

    raw_dir = Path(cfg["data"]["raw_dir"])
    df = scan_raw_dir(raw_dir)
    logger.info(f"Found {len(df)} images across {df['subject_id'].nunique()} subjects.")
    logger.info(f"Class balance: \n{df['label_name'].value_counts()}")

    df = subject_level_split(
        df,
        val_frac=cfg["data"]["val_fraction"],
        test_frac=cfg["data"]["test_fraction"],
        seed=cfg["seed"],
    )
    assert_no_leakage(df)

    out_path = Path(cfg["data"]["split_manifest"])
    df.to_csv(out_path, index=False)
    logger.info(f"Split manifest saved to {out_path}")
    logger.info(df.groupby(["split", "label_name"]).size())


if __name__ == "__main__":
    main()
