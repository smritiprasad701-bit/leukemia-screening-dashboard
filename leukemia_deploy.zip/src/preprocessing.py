"""
Preprocessing utilities: image validation (corrupted/duplicate detection),
resizing, normalization, and augmentation pipelines.

MEDICALLY-REASONABLE vs. NOT-REASONABLE transforms (read before editing):

OK to use (do not change color/morphology unrealistically):
  - Resize (bilinear/bicubic)
  - Horizontal/vertical flip (cell orientation under a microscope is arbitrary)
  - Small rotations (0-360, cells have no canonical "up")
  - Mild brightness/contrast jitter (accounts for illumination variation)
  - Mild Gaussian blur / noise (accounts for focus/sensor variation)
  - Normalization to ImageNet mean/std (needed for transfer learning)
  - Stain/color normalization (Reinhard / Macenko) IF you want to reduce
    cross-batch staining variability -- optional, document if used.

AVOID (can create unrealistic or misleading medical images):
  - Large elastic/warping deformations that distort real cell morphology
    (nuclear shape is diagnostically meaningful -- don't warp it away)
  - Aggressive color transforms that push hue outside plausible Giemsa/Wright
    stain colors (don't turn purple nuclei green, etc.)
  - Cutout/random-erasing that blacks out the nucleus (removes the diagnostic signal)
  - Mixup/CutMix across classes for this task (blends ALL and Hem cell appearance
    into a chimeric, non-physical image -- avoid for this diagnostic classification task)
  - Upsampling tiny cropped cells by a large factor and presenting them as if
    real resolution (introduces interpolation artifacts that look like texture)
"""
from pathlib import Path
from typing import Tuple

import numpy as np
from PIL import Image
import imagehash
import albumentations as A
from albumentations.pytorch import ToTensorV2

IMAGENET_MEAN = (0.485, 0.456, 0.406)
IMAGENET_STD = (0.229, 0.224, 0.225)


def validate_images(raw_dir: str, out_dir: str = "data/processed"):
    """Scan all images: log unreadable/corrupted files and near-duplicate images
    (via perceptual hashing) to text files for manual review."""
    raw_dir = Path(raw_dir)
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    corrupted = []
    hashes = {}
    duplicates = []

    all_files = [p for p in raw_dir.rglob("*") if p.suffix.lower() in
                 {".bmp", ".png", ".jpg", ".jpeg", ".tif", ".tiff"}]

    for p in all_files:
        try:
            img = Image.open(p)
            img.verify()  # cheap corruption check
            img = Image.open(p).convert("RGB")  # reopen after verify()
            h = imagehash.phash(img)
            if h in hashes:
                duplicates.append((str(p), hashes[h]))
            else:
                hashes[h] = str(p)
        except Exception as e:
            corrupted.append((str(p), str(e)))

    (out_dir / "corrupted_files.txt").write_text(
        "\n".join(f"{p}\t{err}" for p, err in corrupted)
    )
    (out_dir / "duplicates.txt").write_text(
        "\n".join(f"{p}\tduplicate_of\t{orig}" for p, orig in duplicates)
    )
    print(f"Scanned {len(all_files)} images.")
    print(f"Corrupted: {len(corrupted)} (see {out_dir/'corrupted_files.txt'})")
    print(f"Near-duplicates: {len(duplicates)} (see {out_dir/'duplicates.txt'})")
    return corrupted, duplicates


def quick_check(raw_dir: str, n: int = 5):
    """Load a handful of images and print basic stats -- fast sanity check."""
    raw_dir = Path(raw_dir)
    files = [p for p in raw_dir.rglob("*") if p.suffix.lower() in {".bmp", ".png", ".jpg"}][:n]
    for p in files:
        img = Image.open(p).convert("RGB")
        arr = np.array(img)
        print(f"{p.name}: size={img.size}, dtype={arr.dtype}, min={arr.min()}, max={arr.max()}")


def get_train_transforms(image_size: int = 224) -> A.Compose:
    """Augmentations applied ONLY to the training split."""
    return A.Compose([
        A.Resize(image_size, image_size),
        A.HorizontalFlip(p=0.5),
        A.VerticalFlip(p=0.5),
        A.RandomRotate90(p=0.5),
        A.Rotate(limit=20, p=0.4, border_mode=0),
        A.RandomBrightnessContrast(brightness_limit=0.15, contrast_limit=0.15, p=0.4),
        A.GaussianBlur(blur_limit=(3, 5), p=0.15),
        A.GaussNoise(var_limit=(5.0, 20.0), p=0.15),
        A.Normalize(mean=IMAGENET_MEAN, std=IMAGENET_STD),
        ToTensorV2(),
    ])


def get_eval_transforms(image_size: int = 224) -> A.Compose:
    """Deterministic transforms for validation/test/inference -- no augmentation."""
    return A.Compose([
        A.Resize(image_size, image_size),
        A.Normalize(mean=IMAGENET_MEAN, std=IMAGENET_STD),
        ToTensorV2(),
    ])


def compute_class_weights(labels) -> Tuple[float, float]:
    """Inverse-frequency class weights for weighted cross-entropy / weighted sampling."""
    labels = np.asarray(labels)
    n0 = (labels == 0).sum()
    n1 = (labels == 1).sum()
    total = n0 + n1
    w0 = total / (2 * n0) if n0 > 0 else 0.0
    w1 = total / (2 * n1) if n1 > 0 else 0.0
    return w0, w1
