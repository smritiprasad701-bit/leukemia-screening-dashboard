"""
Model builders. Baseline = torchvision ResNet50 (ImageNet transfer learning).
Advanced = timm EfficientNet-B0 (or swap to a ViT via config: 'vit_small_patch16_224').
"""
import torch
import torch.nn as nn
import torchvision.models as tvm
import timm


def build_resnet50(num_classes: int = 2, pretrained: bool = True, dropout: float = 0.3) -> nn.Module:
    weights = tvm.ResNet50_Weights.IMAGENET1K_V2 if pretrained else None
    model = tvm.resnet50(weights=weights)
    in_features = model.fc.in_features
    model.fc = nn.Sequential(
        nn.Dropout(dropout),
        nn.Linear(in_features, num_classes),
    )
    return model


def build_timm_model(arch: str = "efficientnet_b0", num_classes: int = 2,
                      pretrained: bool = True, dropout: float = 0.3) -> nn.Module:
    model = timm.create_model(arch, pretrained=pretrained, num_classes=num_classes, drop_rate=dropout)
    return model


def freeze_backbone(model: nn.Module, arch: str):
    """Freeze all parameters except the final classification head."""
    for name, param in model.named_parameters():
        param.requires_grad = False
    head_names = {"fc", "classifier", "head"}  # covers resnet ('fc'), timm efficientnet ('classifier'), vit ('head')
    for name, module in model.named_modules():
        if any(h in name for h in head_names):
            for p in module.parameters():
                p.requires_grad = True


def unfreeze_all(model: nn.Module):
    for p in model.parameters():
        p.requires_grad = True


def build_model(model_type: str, cfg: dict) -> nn.Module:
    num_classes = cfg["data"]["num_classes"]
    dropout = cfg["model"]["dropout"]
    pretrained = cfg["model"]["pretrained"]

    if model_type == "baseline":
        arch = cfg["model"]["baseline_arch"]
        assert arch == "resnet50", "Baseline is defined as ResNet50 in this project."
        return build_resnet50(num_classes, pretrained, dropout)
    elif model_type == "advanced":
        arch = cfg["model"]["advanced_arch"]
        return build_timm_model(arch, num_classes, pretrained, dropout)
    else:
        raise ValueError(f"Unknown model_type {model_type}")
